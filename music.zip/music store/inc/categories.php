<!-- category selection -->
<section class="category">
    <h1>Shop By Category</h1>
    <div class="rows">
        <a href="#" class="cards">
            <img src="./images/offer.png" alt="">
            <p>Offers</p>
        </a>
        <a href="#" class="cards">
            <img src="./images/p1.jpg" alt="">
            <p>Music Instruments</p>
        </a>
        <a href="#" class="cards">
            <img src="./images/book.jfif" alt="">
            <p>Books</p>
        </a>
        <a href="#" class="cards">
            <img src="./images/cassete.png" alt="">
            <p>Cassetes</p>
        </a>
        <a href="#" class="cards">
            <img src="./images/p1.jpg" alt="">
            <p>Deals</p>
        </a>
    </div>

</section>