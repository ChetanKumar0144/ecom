email id  = admin@email.com
password = admin


<!-- for admin panel -->
email= owner@owner.com 
password = owner@owner